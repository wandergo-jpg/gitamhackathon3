<style>
    #uni_modal .modal-content>.modal-footer{
        display:none;
    }
</style>
<div class="container-fluid">
    <?php include 'privacy_policy.html' ?>
</div>

<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
